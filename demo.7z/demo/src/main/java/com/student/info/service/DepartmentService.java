package com.student.info.service;

import javax.validation.Valid;

import com.student.info.entity.Department;
import com.student.info.entity.Student;

public interface DepartmentService {

	 Department createDepartment(Department department);

	 Department updateDepartment(long id, Department department);

}
