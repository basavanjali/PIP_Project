package com.student.info.service;

import java.util.Optional;

import com.student.info.entity.Student;

public interface StudentService {
	
	public Student createStudent(Student student);
	
	public Optional<Student> getStudent(long id);
	
	public void deleteStudent(long id);

	public Student updateStudent(long id, Student current);

	public Student createStudentMapDep(Long depId, Student student);

}
