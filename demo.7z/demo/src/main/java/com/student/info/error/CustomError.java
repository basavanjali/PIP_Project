package com.student.info.error;

public class CustomError {

	 String errorMessage;
	 public CustomError(String errorMessage){
	    	this.errorMessage=errorMessage;
	    }
	 public String getCustomError(){
	    	return errorMessage;
	    }
}
