package com.student.info.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.student.info.entity.Department;
import com.student.info.entity.Student;
import com.student.info.error.CustomErrorType;
import com.student.info.repository.DepartmentRepo;
import com.student.info.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	private StudentRepository studentRepository;
	
	@Autowired
	private DepartmentRepo departmentRepo;

	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}

	List<Student> list = new ArrayList<>();

	@Override
	public Student createStudent(Student student) {
		System.out.println("in service");
		list.add(student);
		return studentRepository.save(student);

	}

	@Override
	public Student updateStudent(long id, Student student) {

		Optional<Student> s1 = Optional.of(studentRepository.findById(id).orElseThrow(() -> new CustomErrorType(id)));

		Student current = s1.get();
		current.setDOB(student.getDOB());
		current.setAddress(student.getAddress());
		current.setName(student.getName());

		return studentRepository.save(current);

	}

	@Cacheable("student")
	@Override
	public Optional<Student> getStudent(long studentId) throws CustomErrorType {

		try {
			System.out.println("Going to sleep for 5 Secs.. to simulate backend call.");
			Thread.sleep(1000 * 5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Optional.of(studentRepository.findById(studentId).orElseThrow(() -> new CustomErrorType(studentId)));

	}

	@Override
	public void deleteStudent(long id) {
		Optional.of(studentRepository.findById(id).orElseThrow(() -> new CustomErrorType(id)));
		System.out.println("delete");
		studentRepository.deleteById(id);
	}

	@Override
	public Student createStudentMapDep(Long depId, Student student) {
		
		Optional<Department> s1 = Optional.of(departmentRepo.findById(depId).orElseThrow(() -> new CustomErrorType(depId)));
		Department current = s1.get();
		
		student.setDepartment(current);
		
		return  studentRepository.save(student);
	}

}
