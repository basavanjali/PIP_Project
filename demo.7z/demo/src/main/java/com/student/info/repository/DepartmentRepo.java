package com.student.info.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.student.info.entity.Department;
@Repository
public interface DepartmentRepo extends CrudRepository<Department, Long> {

}
