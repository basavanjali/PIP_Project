/*
 * package com.student.info.repository;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import org.hibernate.Session; import org.hibernate.SessionFactory; import
 * org.springframework.stereotype.Repository;
 * 
 * import com.student.info.entity.Student;
 * 
 * @Repository("StudentRepository") public class StudentRepositoryImpl
 * implements StudentRepository{
 * 
 * 
 * @Override public void createStudent(Student student) {
 * 
 * List<Student> list = new ArrayList<>(); list.add(student);
 * System.out.println("in repo");
 * 
 * }
 * 
 * }
 */