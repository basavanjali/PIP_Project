package com.student.info.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.student.info.entity.ResponseId;
import com.student.info.entity.Student;
import com.student.info.error.CustomError;
import com.student.info.error.CustomErrorType;
import com.student.info.service.StudentService;

@RestController
@RequestMapping(value = "/student")
public class StudentController {
	
    @Autowired
	private StudentService studentService;
    
    Student s= null;
    
    
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/creat", method = RequestMethod.POST)
	public ResponseEntity<?>  creatStudent(@Valid @RequestBody Student student)  {
		if(student.getAddress()!=null && student.getDOB()!=null && student.getName()!=null) { 
			s= studentService.createStudent(student);
			ResponseId responseId = new ResponseId();
			responseId.setId(s.getId());
		 return new  ResponseEntity<ResponseId>(responseId, HttpStatus.OK);}
		else {	
			 return new ResponseEntity(new CustomError("enter valid details"),
	                    HttpStatus.NOT_FOUND);     
		} }
		
	
	//@Cacheable(cacheNames="headers", condition="#id > 1")  
	@RequestMapping(value = "/get/{id}", method = RequestMethod.GET)
	  public ResponseEntity<?> getUser(@PathVariable long id) {
		  Optional<Student> s1= studentService.getStudent(id);
		  Student current = s1.get();
		 return new ResponseEntity<Student>(current,HttpStatus.OK);
			
	  }


	@RequestMapping(value="/delete/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<?>  deleteStudent(@PathVariable long id)  {
		studentService.deleteStudent(id);
		return new ResponseEntity<Student>(HttpStatus.NO_CONTENT);   
		}
	
	
	 @SuppressWarnings({ "unchecked", "rawtypes" })
	 @RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
	  public ResponseEntity<?> updateStudent(@PathVariable long id,@RequestBody Student student) { 
			 s=studentService.updateStudent(id,student);
		 return new  ResponseEntity<Student>(s, HttpStatus.OK);}
	 
	 @RequestMapping(value = "/{depId}/create", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<?> createBook(@PathVariable(value = "depId") Long depId, @RequestBody Student student) {
		 s= studentService.createStudentMapDep(depId, student);
		 ResponseId responseId = new ResponseId();
			responseId.setId(s.getId());
			return new  ResponseEntity<ResponseId>(responseId, HttpStatus.OK);}
	    
		 
}
