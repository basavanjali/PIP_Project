package com.student.info.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.student.info.entity.Department;
import com.student.info.error.CustomErrorType;
import com.student.info.repository.DepartmentRepo;

@Service
public class DepartmentServiceImpl implements DepartmentService{
	
	@Autowired
	private DepartmentRepo departmentRepo;

	@Override
	public Department createDepartment(Department department) {
		System.out.println("create department");
		return departmentRepo.save(department);
	}
	
	@Override
	public Department updateDepartment(long id, Department department) {

		Optional<Department> s1 = Optional.of(departmentRepo.findById(id).orElseThrow(() -> new CustomErrorType(id)));

		Department current = s1.get();
		current.setHODcontact(department.getHODcontact());
		current.setHODName(department.getHODName());
		return departmentRepo.save(current);

	}
	
	

}
