
package com.student.info.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity(name = "Department")
public class Department {

	@Id
	private long deptId;
	private String depName;
	private String HODName;
	private String HODcontact;

	// @OneToMany(cascade=CascadeType.ALL)

	@OneToMany(mappedBy="department",cascade = CascadeType.ALL)
  //@JoinColumn(name="id") 
	private List<Student> list=new ArrayList<Student>();
  
	@OneToMany(mappedBy="department",cascade = CascadeType.ALL)
	  //@JoinColumn(name="id") 
		private List<Subject> sublist=new ArrayList<Subject>(); 
  public List<Subject> getSublist() {
		return sublist;
	}

	public void setSublist(List<Subject> sublist) {
		this.sublist = sublist;
	}

public List<Student> getList() { return list; }

	public void setList(List<Student> list) {
		this.list = list;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	public String getDepName() {
		return depName;
	}

	public void setDepName(String depName) {
		this.depName = depName;
	}

	public String getHODName() {
		return HODName;
	}

	public void setHODName(String hODName) {
		HODName = hODName;
	}

	public String getHODcontact() {
		return HODcontact;
	}

	public void setHODcontact(String hODcontact) {
		HODcontact = hODcontact;
	}

}
