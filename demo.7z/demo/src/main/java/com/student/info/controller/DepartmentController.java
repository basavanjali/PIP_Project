package com.student.info.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.student.info.entity.Department;
import com.student.info.error.CustomError;
import com.student.info.service.DepartmentService;

@RestController
@RequestMapping(value = "/department")
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
	
	Department d= null;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<?>  creatDepartment(@Valid @RequestBody Department department)  {
		if(department.getDepName()!=null && department.getHODcontact()!=null && department.getHODName()!=null) { 
			d=departmentService.createDepartment(department);
		 return new  ResponseEntity<Department>(d, HttpStatus.OK);}
		else {	
			 return new ResponseEntity(new CustomError("enter valid details"),
	                    HttpStatus.NOT_FOUND);     
		}}
		
		@SuppressWarnings({ "unchecked", "rawtypes" })
		 @RequestMapping(value = "/update/{id}", method = RequestMethod.PUT)
		  public ResponseEntity<?> updateDepartment(@PathVariable long id,@RequestBody Department department) { 
				 d=departmentService.updateDepartment(id, department);
			 return new  ResponseEntity<Department>(d, HttpStatus.OK);}
	
}
