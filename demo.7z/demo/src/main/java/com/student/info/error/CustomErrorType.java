package com.student.info.error;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.NOT_FOUND)
public class CustomErrorType extends RuntimeException{
	
	 
	 public CustomErrorType(Long id) {
		 super(" ID : " +id+ " not found");
		 
	 }
	    public CustomErrorType(String errorMessage){
	       
	    	super(errorMessage);
	    }
	 
}
